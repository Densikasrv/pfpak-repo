#ifndef PLIBC_FCNTL_H
#define PLIBC_FCNTL_H

#ifdef __cplusplus
extern "C" {
#endif

#define O_RDONLY 00000000
#define O_WRONLY 00000001
#define O_RDWR   00000002
#define O_CREAT  00000100
#define O_EXCL   00000200
#define O_TRUNC  00001000
#define O_APPEND 00002000

int open(const char *path, int flags, ...);

#ifdef __cplusplus
}
#endif

#endif
