#ifndef PLIBC_ALLOCA_H
#define PLIBC_ALLOCA_H

#define alloca(size) __builtin_alloca(size)

#endif
