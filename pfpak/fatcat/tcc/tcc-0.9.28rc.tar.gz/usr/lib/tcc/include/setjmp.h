#ifndef PLIBC_SETJMP_H
#define PLIBC_SETJMP_H

#ifdef __cplusplus
extern "C" {
#endif

/* Резерв: ebx, esi, edi, ebp, esp, eip. */
typedef int jmp_buf[6];

int setjmp(jmp_buf environment) __attribute__((returns_twice));
void longjmp(jmp_buf environment, int value) __attribute__((noreturn));

#ifdef __cplusplus
}
#endif

#endif
