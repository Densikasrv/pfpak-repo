#ifndef PLIBC_STDLIB_H
#define PLIBC_STDLIB_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1
#endif

void *malloc(size_t size);
void *calloc(size_t count, size_t size);
void *realloc(void *pointer, size_t size);
void free(void *pointer);

void exit(int code) __attribute__((noreturn));
void _exit(int code) __attribute__((noreturn));
void abort(void) __attribute__((noreturn));

int atoi(const char *string);
long atol(const char *string);
long strtol(const char *string, char **end, int base);
unsigned long strtoul(const char *string, char **end, int base);
long long strtoll(const char *string, char **end, int base);
unsigned long long strtoull(const char *string, char **end, int base);
double strtod(const char *string, char **end);
float strtof(const char *string, char **end);
long double strtold(const char *string, char **end);

int abs(int value);
long labs(long value);

char *getenv(const char *name);
int setenv(const char *name, const char *value, int overwrite);
int unsetenv(const char *name);
char *realpath(const char *path, char *resolved);

void qsort(void *base, size_t count, size_t width,
           int (*compare)(const void *, const void *));
void *bsearch(const void *key, const void *base, size_t count, size_t width,
              int (*compare)(const void *, const void *));

#ifdef __cplusplus
}
#endif

#endif
