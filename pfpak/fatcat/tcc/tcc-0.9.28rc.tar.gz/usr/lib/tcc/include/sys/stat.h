#ifndef PLIBC_SYS_STAT_H
#define PLIBC_SYS_STAT_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef unsigned int mode_t;
typedef unsigned int uid_t;
typedef unsigned int gid_t;
typedef long off_t;

struct stat {
    uint32_t st_dev;
    uint32_t st_ino;
    uint32_t st_mode;
    uint32_t st_nlink;
    uid_t st_uid;
    gid_t st_gid;
    uint32_t st_rdev;
    off_t st_size;
    long st_blksize;
    long st_blocks;
    long st_atime;
    long st_mtime;
    long st_ctime;
};

#define S_IFMT  0170000
#define S_IFDIR 0040000
#define S_IFREG 0100000
#define S_ISDIR(mode) (((mode) & S_IFMT) == S_IFDIR)
#define S_ISREG(mode) (((mode) & S_IFMT) == S_IFREG)

int stat(const char *path, struct stat *buffer);
int fstat(int fd, struct stat *buffer);
int chmod(const char *path, mode_t mode);
int mkdir(const char *path, mode_t mode);

#ifdef __cplusplus
}
#endif

#endif
