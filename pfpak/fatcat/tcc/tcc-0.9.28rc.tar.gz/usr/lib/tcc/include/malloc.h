#ifndef PLIBC_MALLOC_H
#define PLIBC_MALLOC_H

#include <stdlib.h>

#endif
