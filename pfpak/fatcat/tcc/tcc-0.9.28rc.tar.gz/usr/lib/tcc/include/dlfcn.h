#ifndef PLIBC_DLFCN_H
#define PLIBC_DLFCN_H

#ifdef __cplusplus
extern "C" {
#endif

#define RTLD_LAZY   0x001
#define RTLD_NOW    0x002
#define RTLD_GLOBAL 0x100

void *dlopen(const char *filename, int flags);
const char *dlerror(void);
void *dlsym(void *handle, const char *symbol);
int dlclose(void *handle);

#ifdef __cplusplus
}
#endif

#endif
