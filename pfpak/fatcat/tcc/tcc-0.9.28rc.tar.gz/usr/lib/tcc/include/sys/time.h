#ifndef PLIBC_SYS_TIME_H
#define PLIBC_SYS_TIME_H

#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

struct timeval {
    long tv_sec;
    long tv_usec;
};

struct timezone {
    int tz_minuteswest;
    int tz_dsttime;
};

int gettimeofday(struct timeval *value, void *timezone);
int settimeofday(const struct timeval *value, const void *timezone);

#ifdef __cplusplus
}
#endif

#endif
