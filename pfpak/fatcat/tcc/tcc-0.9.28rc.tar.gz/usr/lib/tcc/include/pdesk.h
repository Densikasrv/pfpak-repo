#ifndef PERFIX_PDESK_H
#define PERFIX_PDESK_H

/*
 * SDK сторонних приложений PDesk для Perfix (i686).
 *
 * Программа должна быть статическим ELF32 ET_EXEC для i386 и
 * линковаться с libplibc.a. Графические вызовы работают только когда
 * приложение запущено из PDesk (иконка в доке или меню перфоратора).
 */

#ifdef __cplusplus
extern "C" {
#endif

/* События pdesk_event.kind */
#define PDESK_EVENT_NONE        0
#define PDESK_EVENT_MOUSE_MOVE  1
#define PDESK_EVENT_MOUSE_DOWN  2
#define PDESK_EVENT_MOUSE_UP    3
#define PDESK_EVENT_KEY_DOWN    4
#define PDESK_EVENT_RESIZE      5
#define PDESK_EVENT_CLOSE       6
#define PDESK_EVENT_MINIMIZE    7
#define PDESK_EVENT_EXPOSE      8

/* Кнопки мыши в поле button */
#define PDESK_BUTTON_LEFT  1
#define PDESK_BUTTON_RIGHT 2

/* Коды клавиш, не помещающиеся в байт CP866 */
#define PDESK_KEY_ENTER      0x100
#define PDESK_KEY_BACKSPACE  0x101
#define PDESK_KEY_TAB        0x102
#define PDESK_KEY_ESCAPE     0x103
#define PDESK_KEY_DELETE     0x104
#define PDESK_KEY_HOME       0x105
#define PDESK_KEY_END        0x106
#define PDESK_KEY_UP         0x107
#define PDESK_KEY_DOWN       0x108
#define PDESK_KEY_LEFT       0x109
#define PDESK_KEY_RIGHT      0x10A
#define PDESK_KEY_PAGE_UP    0x10B
#define PDESK_KEY_PAGE_DOWN  0x10C
#define PDESK_KEY_CONTROL    0x200

typedef struct pdesk_event {
    int kind;
    int x;
    int y;
    int button;
    int key;
    int width;
    int height;
    int reserved;
} pdesk_event;

/* Окно */
int pdesk_window_create(int x, int y, int width, int height, const char *title);
int pdesk_window_show(void);
int pdesk_window_close(void);
int pdesk_window_resize(int width, int height);
int pdesk_window_minimize(void);
int pdesk_window_maximize(void);
int pdesk_window_set_title(const char *title);

/* Рисование (цвета 0x00RRGGBB) */
int pdesk_begin_frame(void);
int pdesk_draw_text(int x, int y, unsigned int foreground,
                    unsigned int background, const char *text);
int pdesk_draw_rect(int x, int y, int width, int height, unsigned int color);
int pdesk_draw_rect_outline(int x, int y, int width, int height,
                            unsigned int color);
int pdesk_draw_image(int x, int y, int width, int height, const char *path);

/* События: возвращает 1, если событие получено, 0 при таймауте, -1 при ошибке */
int pdesk_event_poll(pdesk_event *event, unsigned int timeout_ms);

/* Регистрация по манифесту APP.MANIFEST */
int pdesk_register_app(const char *manifest_path);
int pdesk_dock_add_icon(const char *manifest_path);
int pdesk_menu_add_item(const char *manifest_path);
int pdesk_unregister_app(const char *manifest_path);

/* Размер экрана */
int pdesk_screen_width(void);
int pdesk_screen_height(void);

#ifdef __cplusplus
}
#endif

#endif /* PERFIX_PDESK_H */
