#ifndef PLIBC_STDINT_H
#define PLIBC_STDINT_H

#ifdef __cplusplus
extern "C" {
#endif

typedef signed char int8_t;
typedef unsigned char uint8_t;
typedef signed short int16_t;
typedef unsigned short uint16_t;
typedef signed int int32_t;
typedef unsigned int uint32_t;
typedef signed long long int64_t;
typedef unsigned long long uint64_t;

typedef signed int intptr_t;
typedef unsigned int uintptr_t;
typedef signed int intmax_t;
typedef unsigned int uintmax_t;

typedef signed int int_fast8_t;
typedef signed int int_fast16_t;
typedef signed int int_fast32_t;
typedef signed long long int_fast64_t;
typedef unsigned int uint_fast8_t;
typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
typedef unsigned long long uint_fast64_t;

typedef signed char int_least8_t;
typedef signed short int_least16_t;
typedef signed int int_least32_t;
typedef signed long long int_least64_t;
typedef unsigned char uint_least8_t;
typedef unsigned short uint_least16_t;
typedef unsigned int uint_least32_t;
typedef unsigned long long uint_least64_t;

#define INT8_MIN   (-0x7f - 1)
#define INT16_MIN  (-0x7fff - 1)
#define INT32_MIN  (-0x7fffffff - 1)
#define INT64_MIN  (-0x7fffffffffffffffLL - 1)
#define INT8_MAX   0x7f
#define INT16_MAX  0x7fff
#define INT32_MAX  0x7fffffff
#define INT64_MAX  0x7fffffffffffffffLL

#define UINT8_MAX  0xff
#define UINT16_MAX 0xffff
#define UINT32_MAX 0xffffffffU
#define UINT64_MAX 0xffffffffffffffffULL

#define INTPTR_MIN INT32_MIN
#define INTPTR_MAX INT32_MAX
#define UINTPTR_MAX UINT32_MAX
#define INTMAX_MIN INT32_MIN
#define INTMAX_MAX INT32_MAX
#define UINTMAX_MAX UINT32_MAX

#define INT8_C(c)  (c)
#define INT16_C(c) (c)
#define INT32_C(c) (c)
#define INT64_C(c) (c##LL)
#define UINT8_C(c)  (c)
#define UINT16_C(c) (c)
#define UINT32_C(c) (c##U)
#define UINT64_C(c) (c##ULL)

#ifdef __cplusplus
}
#endif

#endif
