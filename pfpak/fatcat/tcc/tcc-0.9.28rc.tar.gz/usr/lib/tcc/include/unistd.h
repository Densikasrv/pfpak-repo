#ifndef PLIBC_UNISTD_H
#define PLIBC_UNISTD_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef int ssize_t;
typedef long off_t;
typedef int pid_t;

#ifndef STDIN_FILENO
#define STDIN_FILENO 0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2
#endif

#ifndef PLIBC_SEEK_DEFINED
#define PLIBC_SEEK_DEFINED
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#endif

#ifndef F_OK
#define F_OK 0
#define X_OK 1
#define W_OK 2
#define R_OK 4
#endif

ssize_t read(int fd, void *buffer, size_t count);
ssize_t write(int fd, const void *buffer, size_t count);
int close(int fd);
off_t lseek(int fd, off_t offset, int whence);
void *sbrk(long increment);

char *getcwd(char *buffer, size_t size);
int chdir(const char *path);
int unlink(const char *path);
int rmdir(const char *path);
int access(const char *path, int mode);
int isatty(int fd);
int getpid(void);
unsigned int sleep(unsigned int seconds);
int usleep(unsigned int microseconds);

extern char **environ;

int execvp(const char *path, char *const argv[]);

#ifdef __cplusplus
}
#endif

#endif
