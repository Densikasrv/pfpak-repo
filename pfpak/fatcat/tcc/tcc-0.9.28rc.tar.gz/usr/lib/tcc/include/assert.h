#ifndef PLIBC_ASSERT_H
#define PLIBC_ASSERT_H

#ifdef __cplusplus
extern "C" {
#endif

void __plibc_assert_fail(const char *expression, const char *file, int line)
    __attribute__((noreturn));

#define assert(expression)                                                   \
    ((expression) ? (void)0                                                  \
                  : __plibc_assert_fail(#expression, __FILE__, __LINE__))

#ifdef __cplusplus
}
#endif

#endif
