#ifndef PLIBC_STRING_H
#define PLIBC_STRING_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

void *memcpy(void *destination, const void *source, size_t count);
void *memmove(void *destination, const void *source, size_t count);
void *memset(void *destination, int value, size_t count);
int memcmp(const void *left, const void *right, size_t count);

size_t strlen(const char *string);
size_t strnlen(const char *string, size_t max_length);
int strcmp(const char *left, const char *right);
int strncmp(const char *left, const char *right, size_t count);
char *strcpy(char *destination, const char *source);
char *strncpy(char *destination, const char *source, size_t count);
char *strcat(char *destination, const char *source);
char *strncat(char *destination, const char *source, size_t count);
char *strchr(const char *string, int character);
char *strrchr(const char *string, int character);
char *strstr(const char *haystack, const char *needle);
char *strpbrk(const char *string, const char *accept);
char *strdup(const char *string);
char *strndup(const char *string, size_t max_length);
char *strerror(int error);

#ifdef __cplusplus
}
#endif

#endif
